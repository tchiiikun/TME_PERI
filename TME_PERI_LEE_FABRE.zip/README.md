# TME_PERI
TME de PERI Irina Lee et William Fabre
Responsable de l'UE : WAJSBÜRT, franck


Description de l'UE :

Cette UE porte sur deux aspects de la gestion des périphériques~: L'utilisation et l'écriture de drivers génériques de périphériques pour le système Linux (modules noyau caractère et USB). La réalisation matérielle et logicielle d'un système embarqué (lecteur MP3 à base de processeur ARM ou Arduino avec interface graphique, carte mémoire, décodeur MP3 matériel, port USB) s'interfaçant avec le système Linux. Les applications abordées (domotique, réseau de capteurs sans fil, lecteur mp3) ne demandent aucun pré-requis en électronique. 
