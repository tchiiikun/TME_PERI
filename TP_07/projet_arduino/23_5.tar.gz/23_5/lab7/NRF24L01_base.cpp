#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <unistd.h>
#include "RF24/RF24.h"
#include <ctime>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sqlite3.h>

typedef uint8_t byte;
using namespace std;
RF24 radio(15,8); // radio(CE,CS)
byte addresses[][6] = {"0XXXX"};
int fd;
char buffer[32];
sqlite3 *db;

void setup()
{
	radio.begin();
	radio.setPALevel(RF24_PA_LOW);
	radio.openReadingPipe(1, addresses[0]);
	radio.printDetails();
	radio.startListening();
}


void loop()
{
	char *query = NULL;
	//~ char* date; // TODO CALCULER LA DATE
	sqlite3_stmt *stmt;
	int ret;

	if( radio.available()){
		radio.read( buffer, sizeof(buffer) );
		asprintf(&query, "INSERT INTO Ard (lumiere) VALUES ('%s');", buffer);
		fprintf(stderr, "Read = %s \n %s\n", buffer, query);
		ret = sqlite3_prepare_v2(db, query, strlen(query), &stmt, NULL);
		if (ret != SQLITE_OK){
			fprintf(stderr, "Could not insert data.\n");
			//goto out_write;
			sqlite3_finalize(stmt);
			free(query);
		}
		
		ret = sqlite3_step(stmt);
		if (ret != SQLITE_DONE){
			fprintf(stderr, "Could not step (ecxecute stmt).\n");
			//goto out_write;
			sqlite3_finalize(stmt);
			free(query);
		}

		/* write(fd, buffer, sizeof(buffer) );*/
		/* write(fd, "\n", 1);*/

		sleep(1);
	}
/*out_write:
		sqlite3_finalize(stmt);
		free(query);*/
}

int main(int argc, char **argv)
{
	int ret;
	char * errmsg;
	sqlite3_stmt *stmt;

	/* fd = open("test.txt", O_RDWR);*/
	setup();

	ret = sqlite3_open("arduino.db", &db);
	if ( ret != SQLITE_OK){
		fprintf(stderr, "Could not open database");
		goto out_open;
	}

	ret = sqlite3_exec(db, "CREATE TABLE Ard (lumiere TEXT);", 0, 0, &errmsg);
	if ( ret != SQLITE_OK){
		fprintf(stderr, "Error in statement: %s [%s].\n", stmt, errmsg);
		goto out_create;
	}
/*
	ret = sqlite3_prepare_v2(db, "CREATE TABLE lux (lumiere TEXT);", -1, &stmt, 0);
	fprintf(stderr, "%d\n", ret);
	if ( ret != SQLITE_OK){
		fprintf(stderr, "Error in statement: %s [%s].\n", stmt, errmsg);
		goto out_open;
	}*/
	/*ret = sqlite3_step(stmt);
	if (ret != SQLITE_DONE){
		fprintf(stderr, "problem on insertion of data");
		goto out_create;
	}*/

	while (1){
		loop();
	}
out_create:
	sqlite3_finalize(stmt);

out_open:
	sqlite3_close(db);
	return 0;
}
